import os
import json
import requests

import boto3
from datetime import datetime

def lambda_handler(event, context):
    sns_topic_arn = os.environ.get('SNS_TOPIC_ARN')
    update_exchange_rates(sns_topic_arn)  # Pasează variabila sns_topic_arn ca argument
    message = "Functia a rulat cu succes"
    return message

def update_exchange_rates(sns_topic_arn):  # Adaugă parametrul sns_topic_arn
    base_currencies = ["GBP", "EUR", "USD"]  # Valuta de referință
    target_currency = "RON"  # Valuta pentru care se dorește cursul
    exchange_rates = {}

    for base_currency in base_currencies:
        exchange_rate = get_exchange_rate(base_currency, target_currency)
        exchange_rates[base_currency] = exchange_rate

    current_date = datetime.now().strftime("%d-%m-%Y")
    message = build_message(exchange_rates, current_date)
    send_message_through_sns(message, sns_topic_arn)

def get_exchange_rate(base_currency, target_currency):
    url = f"https://api.exchangerate-api.com/v4/latest/{base_currency}"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        exchange_rate = data["rates"].get(target_currency)
        if exchange_rate is not None:
            return exchange_rate
        else:
            return f"Nu s-a găsit cursul valutar pentru {target_currency}."
    else:
        return "Eroare la cererea API-ului de curs valutar."

def build_message(exchange_rates, current_date):
    message = f"Cursul valutar de azi, {current_date}, pentru RON este:\n"
    for base_currency, rate in exchange_rates.items():
        message += f"{base_currency}: {rate} RON \n"
    return message

def send_message_through_sns(message, sns_topic_arn):
    sns_client = boto3.client('sns')
    sns_client.publish(
        TopicArn=sns_topic_arn, 
        Subject='Curs valutar pentru RON',
        Message=message
    )
